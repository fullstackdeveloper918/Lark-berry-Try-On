
export default function Banner() {

  return (
    <>
    
    <img src="https://larkandberry.com/cdn/shop/collections/ear-envy-fine-ear-piercings-in-14k-gold-193014.jpg?v=1696620021&width=1728" 
    alt="Banner"  
    className="Banner-image-header"/>
    </>
  )
}

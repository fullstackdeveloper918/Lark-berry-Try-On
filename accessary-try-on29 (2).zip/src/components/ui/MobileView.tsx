  import {} from "@dnd-kit/core" 
 
 export default function MobileView() {
   return (
     <>
{/* 
<DrawerExample>
    <p style={{lineHeight: 2}}>
      Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum ac
      mauris sit amet diam pulvinar vestibulum. Sed malesuada ultrices
      hendrerit.
    </p>

    <Sortable handle />

    <p style={{lineHeight: 2}}>
      Class aptent taciti sociosqu ad litora torquent per conubia nostra, per
      inceptos himenaeos. Nam nisi tortor, egestas volutpat tortor auctor,
      efficitur molestie urna. Vestibulum blandit erat massa, eu ornare diam
      porttitor at.
    </p>
  </DrawerExample> */}

     </>
   )
 }
 